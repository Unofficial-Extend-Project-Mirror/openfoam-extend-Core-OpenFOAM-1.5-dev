// hack for starccm+. the source is already c++ compatibile

#include "ccmio.c"
#include "ccmiocore.c"
#include "ccmioprivate.c"
#include "ccmioutility.c"
#include "ccmioversion.c"
#include "vector.c"
