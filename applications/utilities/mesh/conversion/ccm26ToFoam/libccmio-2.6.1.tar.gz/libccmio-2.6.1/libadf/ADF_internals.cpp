extern "C" {

#include "ADF_internals.c"

}
